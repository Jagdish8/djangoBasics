from django.contrib import admin
from .models import CarModel,Data

# Register your models here.
admin.site.register(CarModel)
admin.site.register(Data)
